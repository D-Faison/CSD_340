
function turnBlue(){
    document.getElementById('lilBuddy').src='images/MushroomThingBlue.png';
}

function turnNormal(){
    document.getElementById('lilBuddy').src='images/MushroomThingNormal.png';
}

function sayHi(){
    document.getElementById('lilBuddy').src='images/MushroomThingWave.png';
}

function turnGreen(){
    document.getElementById('lilBuddy').src='images/MushroomThingGreen.png';
}